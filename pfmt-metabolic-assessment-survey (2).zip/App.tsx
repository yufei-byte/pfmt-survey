
import React, { useState } from 'react';
import { Step, SurveyData } from './types';
import { 
  ChevronRight, ChevronLeft, CheckCircle, ClipboardList, 
  Activity, Heart, Utensils, Info, Copy, Sparkles, MessageCircle, Ruler
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const initialData: SurveyData = {
  name: '', gender: '', age: '', enrollmentDate: new Date().toISOString().split('T')[0],
  diseases: [], otherDisease: '',
  weightLossHistory: '', weightLossMethods: [], otherWeightLossMethod: '', maxWeightLoss: '', isRebound: '',
  antibioticsUsed: '', antibioticsName: '', antibioticsDuration: '', ppiUsed: '', ppiName: '', ppiDuration: '',
  weight: '', height: '', waist: '', hip: '', bodyFat: '',
  fastingGlucose: '', fastingInsulin: '', totalCholesterol: '', triglycerides: '', hdl: '', ldl: '',
  probioticUsage: '', prebioticUsage: '', fermentedUsage: '', fiberIntake: '', sugarIntake: '',
  aerobicExercise: '', strengthTraining: '', sleepQuality: '', stressLevel: '', dietRegularity: '',
  appetiteIntensity: 5, postMealFullness: 5, cravings: 5, bloating: 0, gasFrequency: 0, bowelEffort: 0, energyLevel: 5,
  bristol: { type1: '0', type2: '0', type3: '0', type4: '0', type5: '0', type6: '0', type7: '0' }
};

export default function App() {
  const [step, setStep] = useState<Step>(Step.INTRO);
  const [formData, setFormData] = useState<SurveyData>(initialData);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [copySuccess, setCopySuccess] = useState(false);

  const nextStep = () => setStep(prev => Math.min(prev + 1, Step.SUBMITTED));
  const prevStep = () => setStep(prev => Math.max(prev - 1, Step.INTRO));

  const updateField = (field: keyof SurveyData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: 'diseases' | 'weightLossMethods', item: string) => {
    setFormData(prev => {
      const current = [...prev[field]];
      const index = current.indexOf(item);
      if (index > -1) current.splice(index, 1);
      else current.push(item);
      return { ...prev, [field]: current };
    });
  };

  const generateAIAnalysis = async (data: SurveyData) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `你是一名专业的 pFMT 代谢管理专家。请根据以下客户数据：姓名 ${data.name}，身高 ${data.height}cm，体重 ${data.weight}kg，腰围 ${data.waist}cm，疾病史 ${data.diseases.join(', ')}。请给出 150 字以内的初步代谢评估，语气要专业且亲切。`;
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      setAiAnalysis(response.text || '评估已准备好，请咨询顾问。');
    } catch (e) {
      setAiAnalysis("感谢您的填写！您的代谢数据已录入，顾问将根据您的腰臀比和病史进行深度解析。");
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    await generateAIAnalysis(formData);
    setIsSubmitting(false);
    setStep(Step.SUBMITTED);
  };

  const copyToClipboard = () => {
    const report = `
🌟 pFMT 精准代谢评估报告 🌟
----------------------------
👤 客户：${formData.name} (${formData.gender})
🎂 年龄：${formData.age} 岁
📏 身高/体重：${formData.height}cm / ${formData.weight}kg
📐 腰围/臀围：${formData.waist}cm / ${formData.hip}cm

🏥 健康档案：
- 既往史：${formData.diseases.length > 0 ? formData.diseases.join(', ') : '无'}
- 减重史：${formData.weightLossHistory === 'yes' ? '有过经历' : '无'}
- 减重方式：${formData.weightLossMethods.join(', ') || '无'}

⚡ 代谢感受自评 (0-10)：
- 食欲强度：${formData.appetiteIntensity}
- 精力水平：${formData.energyLevel}
- 餐后饱腹感：${formData.postMealFullness}

🥗 生活习惯评分 (0-3)：
- 益生菌频率：${formData.probioticUsage || '0'}
- 纤维摄入：${formData.fiberIntake || '0'}
- 每周运动：${formData.aerobicExercise || '0'}

📅 评估时间：${new Date().toLocaleString()}
----------------------------
报告已生成，请发送给您的顾问进行深度分析。
    `.trim();

    navigator.clipboard.writeText(report).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-[#F4F7FB] pb-10 pt-6 px-4">
      {/* Progress Bar */}
      {step > 0 && step < 7 && (
        <div className="max-w-2xl mx-auto mb-6 px-2">
          <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-2 uppercase tracking-widest">
            <span>进度</span>
            <span>{Math.round((step / 6) * 100)}%</span>
          </div>
          <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-500 ease-out" 
              style={{ width: `${(step / 6) * 100}%` }}
            />
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/60 overflow-hidden">
        
        {/* Intro Step */}
        {step === Step.INTRO && (
          <div className="p-10 sm:p-14 text-center">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-8">
              <ClipboardList size={40} />
            </div>
            <h1 className="text-2xl font-black text-slate-900 mb-4">pFMT 精准代谢评估</h1>
            <p className="text-slate-500 mb-10 leading-relaxed font-medium">
              基于肠道微生态与临床营养学<br/>为您定制科学减重方案
            </p>
            <button 
              onClick={nextStep}
              className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 active:scale-95 transition-transform"
            >
              开始入组评估
            </button>
            <div className="mt-8 flex justify-center gap-6 text-slate-400">
              <div className="flex flex-col items-center gap-1">
                <Activity size={20} />
                <span className="text-[10px] font-bold">指标</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Utensils size={20} />
                <span className="text-[10px] font-bold">习惯</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Heart size={20} />
                <span className="text-[10px] font-bold">风险</span>
              </div>
            </div>
          </div>
        )}

        {/* Step 1: Basic Info */}
        {step === Step.BASIC_INFO && (
          <div className="p-8">
            <h2 className="text-xl font-bold text-slate-900 mb-8 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm">1</span>
              基础资料
            </h2>
            <div className="space-y-6">
              <div className="group">
                <label className="block text-sm font-bold text-slate-700 mb-2">真实姓名</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={e => updateField('name', e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 rounded-2xl outline-none transition-all font-medium"
                  placeholder="如：张先生"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">性别</label>
                  <div className="flex p-1 bg-slate-100 rounded-xl">
                    {['男', '女'].map(g => (
                      <button
                        key={g}
                        onClick={() => updateField('gender', g)}
                        className={`flex-1 py-3 rounded-lg text-sm font-bold transition-all ${
                          formData.gender === g ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">年龄</label>
                  <input type="number" value={formData.age} onChange={e => updateField('age', e.target.value)} className="w-full px-5 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-indigo-500 outline-none" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Health History */}
        {step === Step.HEALTH_HISTORY && (
          <div className="p-8">
            <h2 className="text-xl font-bold text-slate-900 mb-8 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm">2</span>
              既往病史与减重史
            </h2>
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {['无疾病', '2型糖尿病', '高血压', '脂肪肝', '高尿酸/痛风', '多囊卵巢综合征'].map(d => (
                  <label key={d} className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${formData.diseases.includes(d) ? 'border-indigo-600 bg-indigo-50' : 'border-slate-100 bg-white'}`}>
                    <input type="checkbox" className="hidden" onChange={() => toggleArrayItem('diseases', d)} />
                    <span className="text-sm font-bold text-slate-700">{d}</span>
                  </label>
                ))}
              </div>
              <div className="pt-4 border-t border-slate-100">
                <label className="block text-sm font-bold text-slate-700 mb-4">曾尝试的减重方式</label>
                <div className="flex flex-wrap gap-2">
                  {['节食', '高强度运动', '司美/度拉', '代餐', '中医针灸'].map(m => (
                    <button
                      key={m}
                      onClick={() => toggleArrayItem('weightLossMethods', m)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold border-2 transition-all ${formData.weightLossMethods.includes(m) ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-100 text-slate-400'}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Physical Metrics */}
        {step === Step.PHYSICAL_METRICS && (
          <div className="p-8">
            <h2 className="text-xl font-bold text-slate-900 mb-8 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm">3</span>
              测量数据录入
            </h2>
            <div className="bg-slate-900 p-6 rounded-[2rem] mb-8 flex gap-4 text-white">
              <Ruler className="text-indigo-400 shrink-0" />
              <p className="text-xs leading-relaxed opacity-80">请在早晨空腹、排空大小便后测量，腰围请取肋弓下缘与髂嵴连线中点。</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { id: 'height', label: '身高', unit: 'cm' },
                { id: 'weight', label: '体重', unit: 'kg' },
                { id: 'waist', label: '腰围', unit: 'cm' },
                { id: 'hip', label: '臀围', unit: 'cm' },
              ].map(item => (
                <div key={item.id}>
                  <label className="block text-xs font-bold text-slate-500 mb-2">{item.label}</label>
                  <div className="relative">
                    <input 
                      type="number" 
                      value={formData[item.id as keyof SurveyData] as string}
                      onChange={e => updateField(item.id as keyof SurveyData, e.target.value)}
                      className="w-full px-5 py-4 bg-slate-50 rounded-2xl font-bold text-lg"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">{item.unit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 4-6: Combinational logic for simplicity in this artifact */}
        {step >= Step.LIFESTYLE && step <= Step.GUT_HEALTH && (
          <div className="p-8">
            <h2 className="text-xl font-bold text-slate-900 mb-8 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm">{step}</span>
              {step === 4 ? '行为评估' : step === 5 ? '主观能级' : '肠道健康'}
            </h2>
            {step === 4 && (
              <div className="space-y-6">
                <label className="block text-sm font-bold text-slate-700">益生菌/发酵食品频率</label>
                <div className="grid grid-cols-4 gap-2">
                  {['极少', '偶尔', '较多', '每日'].map((o, i) => (
                    <button key={o} onClick={() => updateField('probioticUsage', String(i))} className={`py-3 text-xs font-bold rounded-xl border-2 transition-all ${formData.probioticUsage === String(i) ? 'border-indigo-600 text-indigo-600 bg-indigo-50' : 'border-slate-50 text-slate-400'}`}>
                      {o}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {step === 5 && (
              <div className="space-y-10">
                {[{ f: 'appetiteIntensity', l: '食欲强度' }, { f: 'energyLevel', l: '日常精力' }].map(s => (
                  <div key={s.f}>
                    <div className="flex justify-between mb-4">
                      <span className="text-sm font-bold text-slate-700">{s.l}</span>
                      <span className="text-2xl font-black text-indigo-600">{formData[s.f as keyof SurveyData] as number}</span>
                    </div>
                    <input type="range" min="0" max="10" value={formData[s.f as keyof SurveyData] as number} onChange={e => updateField(s.f as keyof SurveyData, parseInt(e.target.value))} className="w-full accent-indigo-600" />
                  </div>
                ))}
              </div>
            )}
            {step === 6 && (
              <div className="space-y-4">
                <div className="p-4 bg-amber-50 rounded-2xl text-[10px] text-amber-700 font-medium border border-amber-100">
                  请回想过去一周，不同形态大便出现的频率。
                </div>
                {['IV 型: 理想香蕉状', 'I 型: 严重便秘', 'VII 型: 腹泻水样'].map((t, i) => (
                  <div key={t} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <span className="text-sm font-bold text-slate-700">{t}</span>
                    <input type="number" placeholder="0" className="w-16 p-2 bg-white rounded-lg text-center font-bold" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Step 7: Final Result */}
        {step === Step.SUBMITTED && (
          <div className="p-10 text-center">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={40} />
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-2">评估已完成</h2>
            <p className="text-sm text-slate-400 mb-8 font-medium">请点击下方按钮，复制您的专属评估简报并发送给顾问。</p>
            
            <div className="bg-indigo-50/50 p-6 rounded-[2rem] border border-white shadow-inner text-left mb-8">
               <div className="flex items-center gap-2 mb-3">
                 <Sparkles size={16} className="text-indigo-600" />
                 <span className="text-xs font-black text-indigo-900 uppercase">AI 智能分析预告</span>
               </div>
               <p className="text-sm text-indigo-900/80 leading-relaxed font-medium">
                 {aiAnalysis || "正在为您汇总数据..."}
               </p>
            </div>

            <div className="space-y-4">
              <button 
                onClick={copyToClipboard}
                className={`w-full py-5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all ${copySuccess ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white shadow-xl shadow-slate-200'}`}
              >
                {copySuccess ? "复制成功！去微信粘贴" : <><MessageCircle size={20}/> 一键复制简报发送顾问</>}
              </button>
            </div>
          </div>
        )}

        {/* Actions */}
        {step > 0 && step < 7 && (
          <div className="p-8 bg-slate-50 border-t flex gap-4">
            <button onClick={prevStep} className="flex-1 py-4 bg-white text-slate-400 font-bold rounded-2xl border border-slate-200">上一步</button>
            <button 
              onClick={step === 6 ? handleSubmit : nextStep} 
              className="flex-[2] py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-100"
            >
              {isSubmitting ? '分析中...' : step === 6 ? '完成评估' : '下一步'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
