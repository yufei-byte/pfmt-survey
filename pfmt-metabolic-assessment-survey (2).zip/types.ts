
export interface SurveyData {
  // Basic Info
  name: string;
  gender: string;
  age: string;
  enrollmentDate: string;

  // Medical History
  diseases: string[];
  otherDisease: string;
  weightLossHistory: 'yes' | 'no' | '';
  weightLossMethods: string[];
  otherWeightLossMethod: string;
  maxWeightLoss: string;
  isRebound: 'yes' | 'no' | '';

  // Medication
  antibioticsUsed: 'yes' | 'no' | '';
  antibioticsName: string;
  antibioticsDuration: string;
  ppiUsed: 'yes' | 'no' | '';
  ppiName: string;
  ppiDuration: string;

  // Measurements
  weight: string;
  height: string;
  waist: string;
  hip: string;
  bodyFat: string;

  // Lab Results
  fastingGlucose: string;
  fastingInsulin: string;
  totalCholesterol: string;
  triglycerides: string;
  hdl: string;
  ldl: string;

  // Lifestyle Habits (0-3 scoring)
  probioticUsage: string;
  prebioticUsage: string;
  fermentedUsage: string;
  fiberIntake: string;
  sugarIntake: string;
  aerobicExercise: string;
  strengthTraining: string;
  sleepQuality: string;
  stressLevel: string;
  dietRegularity: string;

  // Subjective Feelings (0-10 scoring)
  appetiteIntensity: number;
  postMealFullness: number;
  cravings: number;
  bloating: number;
  gasFrequency: number;
  bowelEffort: number;
  energyLevel: number;

  // Bristol Stool Scale (frequency per week)
  bristol: { [key: string]: string };
}

export enum Step {
  INTRO = 0,
  BASIC_INFO = 1,
  HEALTH_HISTORY = 2,
  PHYSICAL_METRICS = 3,
  LIFESTYLE = 4,
  DIGESTION = 5,
  GUT_HEALTH = 6,
  SUBMITTED = 7
}
